INSTRUCTION
1. git clone https://github.com/0xSeventy/0X-DDOS
2. cd 0X-DDOS
3. pip3 install -r requiments.txt or python setup.py
4. python main.py
